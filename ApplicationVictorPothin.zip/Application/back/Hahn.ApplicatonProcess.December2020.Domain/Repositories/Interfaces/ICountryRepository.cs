namespace Hahn.ApplicatonProcess.December2020.Domain.Repositories.Interfaces
{
    public interface ICountryRepository
    {
        public bool SearchCountryValid(string countryName);
    }
}